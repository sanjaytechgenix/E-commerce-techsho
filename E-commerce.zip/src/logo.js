import React from "react";
function Logo() {
    return (
       
        <div className="log">
             <ul>
            <div className="home">
                <li><img src="home.png" /></li>
            </div>
            <div className="men">
              <li>  <img src="logom.png" /></li>
            </div>
            <div className="women">
               <li> <img src="logow.png" /></li>
            </div>
            <div className="kid1">
               <li><img src="logok.png" /></li> 
            </div>
            </ul>
            
        </div>
    )
}
export default Logo;