import React  from "react";
function Womens() {
   
    return(
 <div className="womens">
    <div className="container4">
        <div className="wom1">
        <a href="/Home"> <img src="wt.1.png"></img></a>
            <p> FabAlley</p>
            <p>Cost:500Rs (10% OFF)</p>
           
        </div>
        <div className="wom1">
        <a href="/Home">  <img src="wt.2.png"></img></a>
            <p> Bostreet</p>
            <p>Cost:500Rs (15% OFF)</p>
             
        </div>
        <div className="wom1">
        <a href="/Home"><img src="wt.3.png"></img></a>
            <p>Road star</p>
            <p>Cost:500Rs (13% OFF)</p>
             
        </div>
        <div className="wom1">
        <a href="/Home">   <img src="w1.png"></img></a>
            <p> FabAlley</p>
            <p>Cost:500Rs (10% OFF)</p>
           </div>
           <div className="wom1">
           <a href="/Home"> <img src=""></img></a>
            <p> FabAlley</p>
            <p>Cost:500Rs (10% OFF)</p>
           </div>
           <div className="wom1">
           <a href="/Home">  <img src="wt.1.png"></img></a>
            <p> FabAlley</p>
            <p>Cost:500Rs (10% OFF)</p>
           </div>
           <div className="wom1">
           <a href="/Home"> <img src="wt.1.png"></img></a>
            <p> FabAlley</p>
            <p>Cost:500Rs (10% OFF)</p>
           </div>
           <div className="wom1">
           <a href="/Home"> <img src="wt.1.png"></img></a>
            <p> FabAlley</p>
            <p>Cost:500Rs (10% OFF)</p>
           </div>
           <div className="wom1">
           <a href="/Home"><img src="wt.1.png"></img></a>
            <p> FabAlley</p>
            <p>Cost:500Rs (10% OFF)</p>
           </div>
        <div className="wom1">
        <a href="/Home"><img src="wp.1.png"></img></a>
            <p>Mast & Harbour</p>
             <p>Cost:500Rs(15% OFF)</p>
              
        </div>
        <div  className="wom1">
        <a href="/Home">  <img src="wp.2.png"></img></a>
            <p> LEVIS</p>
            <p>Cost:500Rs(10% OFF)</p>
             
        </div>
        <div className="wom1">
        <a href="/Home"> <img src="wp.3.png"></img></a>
       <p>LEE</p>
       <p>Cost:500Rs(10% OFF)</p>
      
</div>
    </div>
</div>
    )
}
export default Womens;