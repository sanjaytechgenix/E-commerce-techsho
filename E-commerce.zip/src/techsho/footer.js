import React from "react";




function Footer(){

    return(

        <div>

<div className="footerone">

    <div className="container10">




<div className="aboutus">

    <h2>About us</h2>

    <p id="serfooter">The fashion store caters to </p>

    <p>thoughtful shoppers Who</p>

    <p>appreciate unique designs and</p>

    <p>top quality pieces you just cant </p>

    <p>find anywhere else</p>




    <div className="footerup">

   <ul>

   <li>   <i id="fb" class='fa fa-facebook'></i></li>

   <li> <i id="lnkdin" class='fa fa-linkedin '></i></li>

   <li>    <i id="twt" class='fa fa-twitter'></i></li>

   <li> <i id="insta" class="fa fa-instagram"></i></li>

   </ul>

    </div>

   

</div>

<div className="aboutus">

<h2> Services</h2>

<p id="serfooter">Website & Application</p>

<p>Development</p>

<p>Digital marketing</p>

<p> design & Branding</p>

<p>Business Strategy</p>

<p>Video and Animation</p>

            </div>




</div>

<div className="aboutus">

<h2>Address</h2>

<p id="add"><a href="https://www.google.com/maps/place/91+Springboard+Business+Hub+P+Ltd/@12.9889025,77.6869043,17z/data=!3m1!4b1!4m6!3m5!1s0x3bae118abb272295:0x45410e57bb8dbf4!8m2!3d12.9889025!4d77.6894792!16s%2Fg%2F11tjl1k7wv?entry=ttu"><i class="fa fa-map-marker"></i></a>  91springboard Outer Ring</p>

<p> Road orr Mahadevapura Service </p>

<p> Lane 512/10, Outer Ring Rd</p>

<p>Mahadevapura,Bengaluru</p>

<p>Karnataka 560048</p>

<p><a href="#"><i class="fa fa-volume-control-phone"></i></a>  +91  9845565656</p>

<p><a href="https://mail.google.com/?"><i class="fa fa-envelope-o"></i></a>  ecomerce@gmail.com</p>

</div>






    </div>




</div>

       

    )

}

export default Footer;