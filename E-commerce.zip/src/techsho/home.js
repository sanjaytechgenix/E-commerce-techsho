import React from "react";
import Fashionapp from "../FashionApp";


function Home(){
    return(
        <div>
             
       
         
            
            <Fashionapp/>

        </div>
    )
}export default Home;